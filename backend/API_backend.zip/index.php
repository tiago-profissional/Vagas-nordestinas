<?php
// backend/index.php - ponto de entrada da API

// ---- CORS ----
// Libera o seu dominio em producao e o localhost durante o desenvolvimento.
$allowedOrigins = [
    'https://vagasnordestinas.com',
    'https://www.vagasnordestinas.com',
    'http://localhost:5173',
];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowedOrigins, true)) {
    header("Access-Control-Allow-Origin: $origin");
}
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

// Em producao e melhor NAO mostrar os erros na tela.
// Deixe como esta enquanto testa; depois pode trocar para 0.
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/router.php';

// Autoload dos controllers
spl_autoload_register(function ($class) {
    if (strpos($class, 'Controllers\\') === 0) {
        $className = substr($class, 12); // remove "Controllers\"
        $file = __DIR__ . '/controllers/' . $className . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

// Conexao com o banco (config/database.php define a funcao getDB)
require_once __DIR__ . '/config/database.php';

$router = new Router();

// Rotas de teste
$router->get('/test', function () {
    response(['success' => true, 'message' => 'Router OK!']);
});

$router->get('/', function () {
    response(['status' => 'online', 'api' => 'Vagas Nordestinas']);
});

// Rotas das vagas
$router->get('/jobs', 'JobController@index');
$router->get('/jobs/:id', 'JobController@show');
$router->post('/jobs', 'JobController@store');
$router->put('/jobs/:id', 'JobController@update');
$router->delete('/jobs/:id', 'JobController@destroy');

// Pega a rota do parametro GET 'route'
$route = $_GET['route'] ?? '/';
if (empty($route)) $route = '/';
if ($route[0] !== '/') $route = '/' . $route;

$router->dispatch($route, $_SERVER['REQUEST_METHOD']);
